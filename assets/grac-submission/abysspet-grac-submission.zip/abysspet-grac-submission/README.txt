어비스펫 (abysspet) — GRAC 등급분류 제출 패키지
================================================

01-game-description.md     게임 설명서 (PDF 변환 후 첨부)
02-demo-and-build-guide.md 시연·빌드·QR 안내
03-privacy-policy.html     개인정보 처리방침
screenshots/               스크린샷
04-demo-video.*            시연 영상
05-abysspet-sandbox.ait    샌드박스 .ait (있는 경우)

문의: nolsoop.games@gmail.com
